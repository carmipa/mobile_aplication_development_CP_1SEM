# 🚀 FIAP 2025 - Mobile Aplication Developement
Este repositório centraliza os trabalhos desenvolvidos na disciplina **Mobile Aplication Developement** do primeiro semestre.

---

## 📚 Disciplina do Semestre

**Mobile Application Development**  
   - Desenvolvimento de aplicativos multiplataforma (Flutter, React Native)  
   - Padrões de navegação e usabilidade mobile  
   - Integração com APIs e serviços externos  
   - Publicação e ciclo de vida de aplicativos em lojas oficiais
     
---

## 🎯 CP1 2025

**Integrantes do CP:**  
**Paulo André Carminati RM557881**  


**Repositório no GitHub:** [CP1 Mobile](https://github.com/carmipa/CP2025_primeiro_semestre/tree/main/mobile_aplication_development/cp_rm557881-Paulo)

